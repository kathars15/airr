#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成中文正常显示、版式清晰的 Word 测试报告。"""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION_START
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Inches, Pt


ROOT = Path(__file__).resolve().parent
OUTPUT_DIR = ROOT / "outputs"
SUMMARY_JSON = OUTPUT_DIR / "simulation_summary.json"
DOCX_OUT = OUTPUT_DIR / "MHT_input_requirement_report.docx"
DOCX_OUT_CN = OUTPUT_DIR / "MHT输入性能需求测试报告.docx"


def set_run_font(run, size_pt: float, bold: bool = False) -> None:
    run.bold = bold
    run.font.name = "SimSun"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "SimSun")
    run.font.size = Pt(size_pt)


def add_paragraph(doc: Document, text: str, *, size: float = 11, bold: bool = False, align=None):
    p = doc.add_paragraph()
    if align is not None:
        p.alignment = align
    r = p.add_run(text)
    set_run_font(r, size, bold=bold)
    p.paragraph_format.space_after = Pt(4)
    return p


def add_heading(doc: Document, text: str, level: int = 1):
    p = doc.add_paragraph()
    r = p.add_run(text)
    set_run_font(r, 14 if level == 1 else 12, bold=True)
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(6)
    return p


def add_bullets(doc: Document, items: list[str]) -> None:
    for item in items:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.22)
        r = p.add_run(f"• {item}")
        set_run_font(r, 11)
        p.paragraph_format.space_after = Pt(2)


def add_kv_table(doc: Document, rows: list[tuple[str, str]]) -> None:
    table = doc.add_table(rows=1, cols=2)
    table.style = "Table Grid"
    table.rows[0].cells[0].text = "项目"
    table.rows[0].cells[1].text = "设定值"
    for key, value in rows:
        cells = table.add_row().cells
        cells[0].text = key
        cells[1].text = value
    for row in table.rows:
        for cell in row.cells:
            for p in cell.paragraphs:
                for run in p.runs:
                    set_run_font(run, 10.5)


def add_image_if_exists(doc: Document, path: Path, title: str, width_in: float = 6.2) -> None:
    if not path.exists():
        return
    add_heading(doc, title, level=2)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    run.add_picture(str(path), width=Inches(width_in))
    doc.add_paragraph("")


def fmt_range(value, unit: str = "") -> str:
    if not value:
        return "无"
    suffix = f" {unit}" if unit else ""
    return f"{value[0]} ~ {value[1]}{suffix}"


def main() -> int:
    payload = json.loads(SUMMARY_JSON.read_text(encoding="utf-8"))
    rows = payload.get("rows", [])
    settings = payload.get("settings", {})
    stability = payload.get("stability_summary", {})
    boundary_rows = payload.get("boundary_rows", [])

    recommended = boundary_rows[-1] if boundary_rows else None
    pass_rows = [row for row in rows if row.get("pass_requirement")]
    fail_rows = [row for row in rows if not row.get("pass_requirement")]
    max_pass_fa = max(float(row["sensor_fa_prob"]) for row in pass_rows) if pass_rows else None
    pass_case = pass_rows[0] if pass_rows else None
    fail_case = fail_rows[0] if fail_rows else None

    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.85)
    section.bottom_margin = Inches(0.85)
    section.left_margin = Inches(0.9)
    section.right_margin = Inches(0.9)

    add_paragraph(doc, "MHT输入性能需求测试报告", size=18, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
    add_paragraph(doc, "基于当前仿真场景的输入性能要求验证结论", size=12, align=WD_ALIGN_PARAGRAPH.CENTER)
    add_paragraph(doc, "本报告重点回答两个问题：当前仿真场景是什么，以及在该场景下，为满足输出指标，输入传感器需要达到什么水平。")

    add_heading(doc, "1. 输出指标要求")
    add_bullets(
        doc,
        [
            "检测率要求：Pd_out >= 0.95",
            "三维位置精度要求：RMSE <= 15.0 m",
            "高度方向精度参考：RMSE_Z 用于单独观察 Up 方向误差",
            "输出虚警率要求：Pfa_out <= 0.05",
        ],
    )

    add_heading(doc, "2. 仿真场景说明")
    add_paragraph(doc, "当前仿真采用同步多传感器三维坐标输入场景。扫描周期为 2.0 s，单次仿真时长为 180.0 s，默认真实目标数量为 2 个。")
    add_paragraph(doc, "当前默认目标类型为多旋翼无人机（multirotor_uav），运动模式为低空缓转、多帧连续推进、越界后反弹。")

    add_kv_table(
        doc,
        [
            ("扫描周期", f"{settings.get('scan_period_sec', 2.0)} s"),
            ("单次仿真时长", f"{settings.get('sim_duration_sec', 180.0)} s"),
            ("真实目标数量", str(settings.get("target_count", 2))),
            ("默认目标类型", "多旋翼无人机"),
            ("初始水平速度范围", "3.0 ~ 18.0 m/s"),
            ("垂直速度典型范围", "约 -0.8 ~ 0.8 m/s"),
            ("真实目标高度范围", "30 ~ 300 m"),
            ("东向活动范围", "-1500 ~ 1500 m"),
            ("北向活动范围", "-1500 ~ 1500 m"),
            ("输入虚假点高度范围", "20 ~ 350 m"),
        ],
    )
    doc.add_paragraph("")

    add_heading(doc, "3. 最终验证结论")
    add_bullets(
        doc,
        [
            f"总测试组合数：{stability.get('total_cases', len(rows))}",
            f"通过组合数：{stability.get('pass_cases', len(pass_rows))}",
            f"通过比例：{stability.get('pass_ratio', 0.0):.2%}",
            (
                f"推荐保守配置：N >= {recommended['min_sensor_count']}，Pd >= {float(recommended['min_sensor_pd_in_pass_set']):.2f}，sigma <= {float(recommended['sensor_pos_std_m']):.1f} m"
                if recommended
                else "当前测试范围内没有找到同时满足三项输出指标的输入组合。"
            ),
            (
                f"在当前通过组合中，最高验证通过的输入虚警率为 {max_pass_fa:.2f}"
                if max_pass_fa is not None
                else "当前没有通过组合，因此无法给出输入虚警率上限。"
            ),
        ],
    )

    add_heading(doc, "4. 稳定输入要求区间")
    add_bullets(
        doc,
        [
            f"传感器数量区间：{fmt_range(stability.get('sensor_count_range'))}",
            f"单传感器检测率区间：{fmt_range(stability.get('sensor_pd_range'))}",
            f"单传感器位置误差标准差区间：{fmt_range(stability.get('sensor_pos_std_range_m'), 'm')}",
            f"单传感器输入虚警率区间：{fmt_range(stability.get('sensor_fa_prob_range'))}",
        ],
    )

    add_heading(doc, "5. 代表性案例")
    if pass_case:
        add_paragraph(
            doc,
            f"通过案例：N={pass_case['sensor_count']}，Pd={float(pass_case['sensor_pd']):.2f}，sigma={float(pass_case['sensor_pos_std_m']):.1f} m，Pfa_in={float(pass_case['sensor_fa_prob']):.2f}；"
            f"对应输出 Pd_out={float(pass_case['detection_rate']):.3f}，RMSE={float(pass_case['rmse_m']):.2f} m，RMSE_Z={float(pass_case['rmse_z_m']):.2f} m，Pfa_out={float(pass_case['false_alarm_rate']):.3f}。"
        )
    if fail_case:
        add_paragraph(
            doc,
            f"临界失败案例：N={fail_case['sensor_count']}，Pd={float(fail_case['sensor_pd']):.2f}，sigma={float(fail_case['sensor_pos_std_m']):.1f} m，Pfa_in={float(fail_case['sensor_fa_prob']):.2f}；"
            f"对应输出 Pd_out={float(fail_case['detection_rate']):.3f}，RMSE={float(fail_case['rmse_m']):.2f} m，RMSE_Z={float(fail_case['rmse_z_m']):.2f} m，Pfa_out={float(fail_case['false_alarm_rate']):.3f}。"
        )

    add_heading(doc, "6. 敏感性说明")
    add_bullets(
        doc,
        [
            "检测率主要受传感器数量和单传感器检测率影响。",
            "三维位置 RMSE 主要受单传感器位置误差标准差影响。",
            "Z方向精度可以通过 RMSE_Z 单独观察。",
            "输出虚警率主要受输入虚警率和 MHT 起轨/确认参数影响。",
            "从当前结果看，最容易先失效的指标通常是输出虚警率 Pfa_out。",
        ],
    )

    doc.add_section(WD_SECTION_START.NEW_PAGE)
    add_heading(doc, "7. 轨迹图")
    add_paragraph(doc, "以下图件用于直观展示真实轨迹、MHT 输出轨迹以及高度方向误差。")
    add_image_if_exists(doc, OUTPUT_DIR / "trajectory_compare_3d.png", "7.1 三维轨迹对比图", width_in=6.4)
    add_image_if_exists(doc, OUTPUT_DIR / "trajectory_compare_timeseries.png", "7.2 三方向时间序列图", width_in=6.4)
    add_image_if_exists(doc, OUTPUT_DIR / "trajectory_z_error_timeseries.png", "7.3 Z方向轨迹与误差图", width_in=6.4)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    doc.save(DOCX_OUT)
    shutil.copyfile(DOCX_OUT, DOCX_OUT_CN)
    print(str(DOCX_OUT))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
